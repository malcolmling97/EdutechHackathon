import study from '../../tmp/study.json';

// Mock data for study list
export const getStudyList = async () => {
    //for testing purposes
    return Promise.resolve(study);
  }; 