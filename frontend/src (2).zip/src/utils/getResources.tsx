
import resources from '../../tmp/resources.json';

export const getResources = async () => {
  //for testing purposes
  return Promise.resolve(resources);
}; 